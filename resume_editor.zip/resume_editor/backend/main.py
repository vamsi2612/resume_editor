from fastapi import FastAPI, Request
from pydantic import BaseModel
import json

app = FastAPI()

class EnhanceRequest(BaseModel):
    section: str
    content: str

@app.post("/ai-enhance")
def ai_enhance(data: EnhanceRequest):
    return {"enhanced": f"Enhanced {data.section}: {data.content} [AI improved]"}

@app.post("/save-resume")
async def save_resume(request: Request):
    resume = await request.json()
    with open("resume.json", "w") as f:
        json.dump(resume, f, indent=4)
    return {"status": "Resume saved successfully"}
