import React from 'react';
import ResumeEditor from './components/ResumeEditor';
function App() {
  return (
    <div>
      <h1>Resume Editor</h1>
      <ResumeEditor />
    </div>
  );
}

export default App;