import React, { useState } from 'react';

function ResumeEditor() {
  const [resume, setResume] = useState({
    name: "",
    experience: "",
    education: "",
    skills: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setResume({ ...resume, [name]: value });
  };

  const enhanceSection = async (section) => {
    const res = await fetch("http://127.0.0.1:8000/ai-enhance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ section, content: resume[section] })
    });
    const data = await res.json();
    setResume({ ...resume, [section]: data.improved_content });
  };

  const saveResume = async () => {
    await fetch("http://127.0.0.1:8000/save-resume", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resume })
    });
    alert("Resume saved!");
  };

  const downloadJSON = () => {
    const blob = new Blob([JSON.stringify(resume, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "resume.json";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div>
      {Object.keys(resume).map((section) => (
        <div key={section}>
          <label>{section.toUpperCase()}</label><br />
          <textarea name={section} value={resume[section]} onChange={handleChange} /><br />
          <button onClick={() => enhanceSection(section)}>Enhance with AI</button>
          <hr />
        </div>
      ))}
      <button onClick={saveResume}>Save Resume</button>
      <button onClick={downloadJSON}>Download Resume</button>
    </div>
  );
}

export default ResumeEditor;